# TareaINFO088
Tarea en la que se pondra a prueba el conocimiento de estructuras de datos y algoritmos aprendidos durante el semestre.

La carpeta Lab-Ejemplo es una guia para hacer la medicion de los tiempos de ejecucion del programa, eviten modificar el contenido de esta carpeta.

## Para ejecutar el programa fuente:
1) Entrar en la carpeta "Codigo-Fuente"
2) Ejecutar el comando
`make`
3) Ejecutar el comando
`./bin/file_experiments`
